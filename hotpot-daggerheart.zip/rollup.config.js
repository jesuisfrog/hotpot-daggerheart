export default {
  input: "./hotpot.mjs",
  output: {
    file: './public/hotpot.mjs',
    format: 'esm',
  },
};